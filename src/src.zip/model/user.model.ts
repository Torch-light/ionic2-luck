export class User{
    id:number; 
    role_id:number;
    name:string;
    invite_id:number;
    point:number;
    img:string;
    delete:boolean;
}
import { NgModule, ErrorHandler } from '@angular/core';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';
import { LoginPage } from '../pages/login/login';
import { TabsPage } from '../pages/tabs/tabs';
import { HomePage } from '../pages/home/home';
import { ActionPage } from '../pages/action/action';
import { HistoryPage } from '../pages/history/history';
import { SeetingPage } from '../pages/seeting/seeting';
// import { RegisterPage } from '../pages/register/register';
import { RechargePage } from '../pages/recharge/recharge';
import { CashPage } from '../pages/cash/cash';
import { MinehistoryPage } from '../pages/minehistory/minehistory';
import { FromComponent } from '../compoent/from-component/from';
import { BoxComponent } from '../compoent/box-component/box';
import {apiService} from '../service/api.service';
import {Utils} from '../helps/utils';
// import { HttpModule }    from '@angular/http';
// import { fromService } from '../service/from-service';
// import { Utils } from '../config/utils.service';

@NgModule({
  declarations: [
    MyApp,
    LoginPage,
    TabsPage,
    HomePage,
    ActionPage,
    SeetingPage,
    HistoryPage,
    FromComponent,
    RechargePage,
    BoxComponent,
    MinehistoryPage,
    CashPage,
    // SwapPage
    // fromService
  ],
  imports: [
    // HttpModule,
    IonicModule.forRoot(MyApp,
    {backButtonText:'返回'},
    // {
      // links:[
      // {component:RegisterPage,name:'register',segment:'register'},
      // {component:TabsPage,name:'tabs',segment:'action'},
      // {component:ActionPage,name:'action',segment:'action'},
      // {component:SeetingPage,name:'seeting',segment:'seeting'},
      // {component:HistoryPage,name:'history',segment:'history'},
      // {component:HomePage,name:'',segment:'home'},
      // {component:RegisterPage,name:'register',segment:'register'}
    // ]}
    )
    
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    LoginPage,
    TabsPage,
    HomePage,
    ActionPage,
    SeetingPage,
    HistoryPage,
    FromComponent,
    RechargePage,
    BoxComponent,
    MinehistoryPage,
    CashPage,
    // SwapPage

    // fromService
  ],
  providers: [{provide: ErrorHandler, useClass: IonicErrorHandler},apiService,Utils]
})
export class AppModule {}

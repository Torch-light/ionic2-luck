import {Injectable,Component} from "@angular/core";
import {Http,Response,Headers,RequestOptions} from "@angular/http";

@Injectable()
// @Component({
//     providers
// })
export class apiService{
    objs=Object;
    constructor(public http:Http){}
    call(method:string,url:string,obj:Object,isNeedToken?:boolean):any{
        let _method=method.toUpperCase();
        let _resulte;
        //  let headers = new Headers({ 'Content-Type': 'application/json' });
    // let options = new RequestOptions({ headers: headers });
        switch(_method){
            case 'GET':
            let _url=this.joint(url,obj);
            _resulte=this.http.get(_url)
            break;
            case 'POST':
            console.log(obj);
            _resulte=this.http.post(url,obj);
            break;
            case 'DELETE':
            break;
            case 'JSOP':
            break;
            case 'PUT':
            break;
        }
        console.log(_resulte)
        return _resulte;
    }
    joint(url:string,obj:Object):string{
        let _url=url+'?';
        let arr=[];
        for (var i in obj){
            arr.push(i+'='+obj[i]);
        }
        _url+=(arr.join('&'));
        return _url;
    }
    // httpCalzl(url:string):Object{
    //     let obj=this.http.get(url);
    //     return obj;
    // }
}
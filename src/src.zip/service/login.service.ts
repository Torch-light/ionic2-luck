import {Injectable,Component} from "@angular/core";
import {Http,Response} from "@angular/http";
// import {Observable} from "rxjs/Observable";
import {Config} from "../helps/config";
import {User} from "../model/user";
import {apiService} from "./api.service";
import 'rxjs/add/operator/map';
@Injectable()
export class loginService{

    config=Config;
    constructor(public http:Http,
                public apiService:apiService){


    }

    getUser(obj):Object{
        let url=this.config.url+this.config.login;
         this.apiService.call('post',url,obj,false)
            .map(data=>console.log('map'+data))  //2
            .subscribe(  //3
                data => console.log(data),
                err => console.log(err),
            );
        return {
            a:123,
            b:12,
            c:2131,
            dsad:'dasd'
        }
    }
    handleError():void{

    }
}
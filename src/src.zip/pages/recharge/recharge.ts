import { Component } from '@angular/core';
import { NavController, NavParams,ToastController } from 'ionic-angular';
import { Http }    from '@angular/http';
import { Config }    from '../../helps/config';
/*
  Generated class for the Recharge page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-recharge',
  templateUrl: 'recharge.html'
})
export class RechargePage {
  options:Array<string>=[
    '微信',
    '支付宝'
    ];
  payType:string='微信';
  rechargeText:string;
  model:any={
    money:null,
    paytype:null
  };
  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              public toastCtrl: ToastController,
              public http:Http
              ) {
    
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad RechargePage');
    console.log(Config);
  }
  history():void{

  }
  selectPayType(options):void{
      this.payType=options;
      if(options==='weixin'){
        this.model.paytype=0;
      }else{
        this.model.payType=1;
      }
  }


presentToast() {
  let toast = this.toastCtrl.create({
    message: '还有充值等待审核',
    duration: 3000,
    position: 'top',
    showCloseButton:true,
    cssClass:'toastCss',
    closeButtonText:'close'
  });

  toast.onDidDismiss(() => {
    console.log('Dismissed toast');
    if(this.model.money){
      this.model.money=null;
    }
  });

  toast.present();
}
  submit():void{
    this.rechargeText=this.payType;
    console.log(this.rechargeText);
    this.presentToast();
  }
  
  get getRecharge():string{
    return '123';
  }
}

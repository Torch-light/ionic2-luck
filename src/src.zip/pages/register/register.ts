import { Component } from '@angular/core';
import { NavController, NavParams,App } from 'ionic-angular';
// import {FromComponent} from '../../compoent/from-component/from'
// import {fromDate} from '../../compoent/from-date.module'
// import { fromDate } from './from-date.module';
import {fromDate} from '../../compoent/from-component/from-date.module';
/*
  Generated class for the Register page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-register',
  templateUrl: 'register.html'
})
export class RegisterPage {
   fromDate=[
   	new fromDate('用户名','text','name'),
   	new fromDate('密码','password','password'),
   	new fromDate('验证码','text','code')
   ]	
  constructor(public navCtrl: NavController, 
  			  public navParams: NavParams,
  			  public appCtrl:App) {}

  ionViewDidLoad() {
    console.log('ionViewDidLoad RegisterPage');
  }
  submit(fromdate:fromDate){
    console.log(fromdate);
  }
}

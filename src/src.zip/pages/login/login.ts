import { Component,ViewChild } from '@angular/core';
import { NavController, NavParams,App,ViewController,ToastController } from 'ionic-angular';
import {fromDate} from '../../compoent/from-component/from-date.module';
import {Storage} from '@ionic/storage';
// import { fromService } from '../../service/from-service';
// import { RegisterPage } from '../register/register';
import { TabsPage } from '../tabs/tabs';
// import { HomePage } from '../home/home';
import { loginService } from '../../service/login.service';
import {Utils} from '../../helps/utils'


/*
  Generated class for the Login page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
  styleUrls:['./build/main.css'],
  providers:[loginService,Utils]
})
export class LoginPage {
@ViewChild('myNav') nav:NavController
   fromdate:Array<fromDate>=[];
   indexState:boolean=false; //false:login  true:register
   model:Object;
   headText:string;
  constructor(public navCtrl: NavController, 
                public navParams: NavParams,
                public appCtrl:App,
                public viewCtrl:ViewController,
                public loginService:loginService,
                public utils:Utils,
                public toastCtrl:ToastController
                ) {

    // console.log(this.ut.platForm().then(dd=>console.log(dd)));
  }
  ionViewDidLoad() {
    this.login();
    // this.utils.getLocalStorage('name');
    // console.log(this.storage);
    // this.storage.set('config',config);
//     this.fromdate=[
//  	new fromDate('yonghu','text','username'),
//  	new fromDate('password','password','password')
//  ];
   
  }
  submit(obj:Object):void{
    var statistic:number=0;
    this.model=obj;
    for(let i in this.model){
      console.log('1231232'+i);
      console.log('dddddd'+this.model);
      if(this.fromdate[i] in this.model){
        console.log('没有');
        if(statistic){
          statistic--;
        }
      }else if(this.model[i].length>0)
      {
        statistic++;
        console.log('有');
      }
    }  
    if(statistic===this.fromdate.length){
      console.log('验证通过')
    let userInfo=this.loginService.getUser(obj);
    } else{
      this.errorToast();
    }
    // console.log(userInfo);
    // this.viewCtrl.dismiss();
    // this.appCtrl.getRootNav().push(TabsPage);
    // this.navCtrl.push(HomePage);
  }
  register():void{
      this.fromdate=[
 	new fromDate('用户名','text','username'),
 	new fromDate('密码','password','password'),
   new fromDate('验证码','text','code')
 ];
 this.headText='注册';
 this.indexState=true;
  }
  login():void{
     this.fromdate=[
 	new fromDate('用户名','text','username'),
 	new fromDate('密码','password','password')
 ];
 this.indexState=false;
 this.headText='登陆';
  }
 close():void{
 this.viewCtrl.dismiss();
 }
    // this.appCtrl.getRootNav().push(RegisterPage);
  
errorToast() {
  let toast = this.toastCtrl.create({
    message: '用户名或密码不能为空',
    duration: 1000,
    position: 'top',
    showCloseButton:true,
    cssClass:'toastCss',
    closeButtonText:'close'
  });

  toast.onDidDismiss(() => {
    console.log('Dismissed toast');
    
  });

  toast.present();
}
 
}

import { Component } from '@angular/core';
import { NavController, NavParams,ModalController,App } from 'ionic-angular';
// import {ActionPage} from "../action/action";
import {LoginPage} from "../login/login";
import {boxDate} from "../../compoent/box-component/box-date.module";
import {RechargePage} from "../recharge/recharge";
import {CashPage} from "../cash/cash";
import {MinehistoryPage} from "../minehistory/minehistory";
import {Utils} from "../../helps/utils";
/*
  Generated class for the Home page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-home',
  templateUrl: 'home.html',
  styleUrls:['build/main.css']
})
export class HomePage {
  boxs:Array<Object>=[];
  islogin:boolean=false;
  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              public modelCtrl:ModalController,
              public appCtrl:App,
              public utils :Utils) {}

  ionViewDidLoad() {
    console.log('ionViewDidLoad HomePage');
    this.boxs=[{id:0,name:'充值'},
    {id:1,name:'提现'},
    {id:2,name:'我的记录'},
    {id:3,name:'我的资金盘'},
    ]
    this.init();
  }
  login():void{
    let modelLogin=this.modelCtrl.create(LoginPage);
    modelLogin.present();
    // this.navCtrl.push(LoginPage);
  }
  boxClick(box):void{
    switch (box.id){
      case 0:
      this.appCtrl.getRootNav().push(RechargePage);
      // this.navCtrl.push(RechargePage);
      break;
      case 1:
      this.appCtrl.getRootNav().push(CashPage);
      break;
      case 2:
      this.appCtrl.getRootNav().push(MinehistoryPage);
      break;
      case 3:
      break;

    }
  }
  init():void{
    let islogin=this.utils.isLogin();
    if(islogin){
      this.islogin=true;
    }else{
      this.islogin=false;
    }
  }
  
}

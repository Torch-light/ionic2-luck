import { Component,Input,Output,EventEmitter } from '@angular/core';
// import { FormsModule } from '@angular/forms';
// import { fromDate } from './from-date.module';
// import { fromService } from '../../service/from-service';
import { Subscription }   from 'rxjs/Subscription';

/*
  Generated class for the Login page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'from-table',
  templateUrl: 'from.component.html'
})
export class FromComponent {
  @Input ('fromObj') objs;
  @Output () submit=new EventEmitter <Object>();
  model={};
  // fromService:fromService;
  subscription:Subscription;
  constructor() {
     
  }
  ngOnInit(){
  	for(let o in this.objs){
  		this.model[this.objs[o].date]='';

  	}
  }
  // get (){
  //   return this.model;
  // }
  _submit(){
    let obj={};
    for(var i in this.model){
      obj[i]=this.model[i];
    }
    this.submit.emit(obj);
    // this.fromService.setItem(this.model);
  }
 }


export class fromDate{
	constructor(
		public value:string,
		public type:string,
		public date:string
		){}
}
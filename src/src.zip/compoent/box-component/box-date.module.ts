export class boxDate{
    constructor(public className:string,
                public funName:string,
                public text:string){

    }
}
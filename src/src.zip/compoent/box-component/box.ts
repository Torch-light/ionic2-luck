import {Component,Input,Output} from "@angular/core";
import {boxDate} from "./box-date.module";

@Component({
    selector:'box',
    templateUrl:'box.component.html',
    styleUrls:['build/main.css'],
})

export class BoxComponent{
    @Input('boxs') boxs;

}
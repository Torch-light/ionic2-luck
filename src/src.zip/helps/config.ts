export const Config={
    url:'http://localhost:8001/api/',
    login:'login',
    user:'user',
    register:'register',
    cash:'cash',
    recharge:'recharge',
    history:'history',
}
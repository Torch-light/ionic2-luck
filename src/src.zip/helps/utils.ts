import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
@Injectable()
export class Utils {
	setLocalStorage (name,value){
		window.localStorage.setItem('name',JSON.stringify(value));
	}
	getLocalStorage(name){
		let obj:Object;
		let _obj=window.localStorage.getItem('name');
		if(_obj!==null){
		obj=JSON.parse(_obj);
		return obj;
		}else{
			return false;
		}
	}

	clearAllLocalStorage(){
		window.localStorage.clear();
	}

	clearLocalStorage(name){
		window.localStorage.removeItem('name');
	}

	isLogin():Boolean{
		let userInfo=this.getLocalStorage('userInfo');
		console.log(typeof userInfo);
		if(typeof userInfo ==='boolean'){
			return false;
		}else{
			return true;
		}
		
	}
}